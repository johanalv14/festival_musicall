# Clase base Artista

class Artista:
    def __init__(self, nombre, genero, popularidad):
        self.nombre = nombre
        self.genero = genero
        self.popularidad = popularidad

    def presentarse(self):
        print(f"🎤 Hola, soy {self.nombre}, interpreto música de género {self.genero}.")

    def actuar(self):
        print(f"{self.nombre} está actuando en el escenario...")

    def despedirse(self):
        print(f"👏 {self.nombre} agradece al público por su apoyo.\n")
